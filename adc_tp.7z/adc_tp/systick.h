#ifndef _SYSTICK_H_
#define _SYSTICK_H_

void init_systick(void);
uint32_t get_systick(void);

#endif